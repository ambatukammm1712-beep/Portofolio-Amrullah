exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { message, history = [] } = JSON.parse(event.body);
    
    if (!message) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Message required' }) };
    }

    const systemPrompt = `Kamu asisten AI portofolio M. Amrullah. Gaya: santai, ramah, singkat, pakai emoji ⚡. 
    Tentang Amrullah: Web developer, coding di HP pakai Termux+SPCK. Project: TikTok Downloader, Image-to-Link. 
    Kontak: WA: https://wa.me/6288291975215 | Email: yonkounoamz@gmail.com | IG: @jarwo23668.
    Jawab pertanyaan seputar portofolio. Jika diminta kontak, berikan link.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.slice(-6),
      { role: 'user', content: message }
    ];

    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
       model: 'qwen-2.5-8b-instruct',
        messages,
        temperature: 0.6,
        max_tokens: 500
      })
    });

    if (!res.ok) throw new Error('Groq API error');
    const data = await res.json();
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ reply: data.choices[0].message.content })
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Server error: ' + err.message })
    };
  }
};